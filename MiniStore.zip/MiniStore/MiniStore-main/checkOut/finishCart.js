localStorage.counter = 0;
localStorage.cost = 0 ;
localStorage.productInCart = "";